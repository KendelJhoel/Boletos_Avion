﻿public class PagoData
{
    public int IdVuelo { get; set; }
    public List<int> Asientos { get; set; }
}
