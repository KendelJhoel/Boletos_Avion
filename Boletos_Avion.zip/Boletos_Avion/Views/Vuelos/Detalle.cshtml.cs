using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Boletos_Avion.Views.Vuelos
{
    public class DetalleModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
